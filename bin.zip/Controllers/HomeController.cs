﻿
using Microsoft.AspNetCore.Mvc;
using austin_heisley_cook_price_quotation.Models;
using static austin_heisley_cook_price_quotation.Models.PriceQuotationModel;

namespace PriceQuotationApp.Controllers
{
    public class PriceQuotationController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new PriceQuotation());
        }

        [HttpPost]
        public IActionResult Index(PriceQuotation quote)
        {
            if (ModelState.IsValid)
            {
                return View(quote);
            }

            return View(quote);
        }
    }
}
