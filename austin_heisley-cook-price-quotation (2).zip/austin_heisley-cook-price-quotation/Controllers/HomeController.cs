﻿
using Microsoft.AspNetCore.Mvc;
using PriceQuotationMVC.Models;

namespace PriceQuotationMVC.Controllers
{
    public class PriceQuotationController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new PriceQuotationModel());
        }

        [HttpPost]
        public IActionResult Index(PriceQuotationModel quote)
        {
            if (ModelState.IsValid)
            {
                return View(quote);
            }
            return View(quote);
        }
    }
}
