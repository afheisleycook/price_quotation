﻿
using System.ComponentModel.DataAnnotations;

namespace PriceQuotationMVC.Models
{
    public class PriceQuotationModel
    {
        [Required]
        public decimal? Subtotal { get; set; }

        [Required]
        public decimal? DiscountPercent { get; set; }

        public decimal? DiscountAmount => Subtotal * (DiscountPercent / 100);
        public decimal? Total => Subtotal - DiscountAmount;
    }
}
