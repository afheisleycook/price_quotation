﻿using System.ComponentModel.DataAnnotations;

namespace austin_heisley_cook_price_quotation.Models
{
    public class PriceQuotationModel
    {
        public class PriceQuotation
        {
            [Required(ErrorMessage = "Enter subtotal.")]
            [Range(0.01, 100000, ErrorMessage = "Enter a valid subtotal.")]
            public decimal? Subtotal { get; set; }

            [Required(ErrorMessage = "Enter discount percent.")]
            [Range(0, 100, ErrorMessage = "Discount must be between 0 and 100.")]
            public decimal? DiscountPercent { get; set; }

            public decimal? DiscountAmount => Subtotal * (DiscountPercent / 100);
            public decimal? Total => Subtotal - DiscountAmount;
        }
    }
}
